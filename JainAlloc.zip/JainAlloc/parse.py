import pdfplumber, re, json, collections
pdf=pdfplumber.open('/mnt/user-data/uploads/Batch_Timetables_All_Programs.pdf')
DAYS=['Mon','Tue','Wed','Thu','Fri','Sat']
batches=[]; bookings=collections.defaultdict(set)  # room -> set((d,p))
detail=collections.defaultdict(list)
bad=[]
for pi,page in enumerate(pdf.pages[1:],start=2):
    txt=page.extract_text() or ''
    m=re.search(r'^(.+?) — Semester (\d+) — Sec\S*\s*(\w+)',txt,re.M)
    if not m: bad.append(pi); continue
    prog,sem,sec=m.group(1).strip(),m.group(2),m.group(3)
    tabs=page.extract_tables()
    if not tabs: bad.append(pi); continue
    rows=tabs[0]
    label=f'{prog} S{sem}-{sec}'
    batches.append(label)
    for r in rows[1:]:
        if not r or r[0] not in DAYS: continue
        d=DAYS.index(r[0]); prev=None
        for p in range(1,8):
            c=r[p] if p<len(r) else None
            if c is None:
                c=prev
            else:
                c=re.sub(r'\s+',' ',c).strip()
            prev=c
            if not c: continue
            mm=re.search(r'\bin\s+(\d{3}[A-C]?)\b',c)
            if mm and 'Lunch' not in c:
                room=mm.group(1)
                bookings[room].add((d,p-1))
                detail[room].append((d,p-1,label,c))
print(len(batches),'batches; bad pages',bad)
print(len(bookings),'rooms booked')
for r,s in sorted(bookings.items()): print(r,len(s))
json.dump({r:sorted(s) for r,s in bookings.items()},open('bookings.json','w'))
json.dump({r:[list(x) for x in v] for r,v in detail.items()},open('detail.json','w'))
