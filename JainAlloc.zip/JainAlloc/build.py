import json,re,collections
g=json.load(open('/mnt/user-data/uploads/graph.json'))
det=json.load(open('detail.json'))
nodes={n['id']:n for n in g['nodes']}
OV={'F4-412':dict(cap=30,label='412 VFX & Recording',lab=True),
    'F1-124A':dict(cap=72,label='124AB Graphics Lab',lab=True),
    'F3-318':dict(cap=60,label='318B Mathematics Lab',lab=True),
    'F3-322A':dict(cap=66),}
rooms={}
def mk(i,label,lab,cap):
    rooms[i]=dict(id=i,label=label,floor=nodes[i]['floor'],cap=cap,lab=lab,A=['0']*42,B=['0']*42)
for i,n in nodes.items():
    if n['kind']!='room': continue
    nm=n.get('name','')
    lec = nm=='Lecture Hall' or nm.startswith('Room ')
    o=OV.get(i,{})
    mk(i,o.get('label',f"{n['aliases'][0]} {nm}"),o.get('lab',not lec),o.get('cap',60 if lec else 40))
unmapped=collections.Counter()
for r,lst in det.items():
    gid=f"F{r[0]}-{r}"
    if gid not in rooms: unmapped[r]+=1; continue
    for d,p,label,c in lst:
        k='A' if label.startswith('CSE-GEN') else 'B'
        rooms[gid][k][d*7+p]='1'
print('unmapped',dict(unmapped))
out=[dict(r,A=''.join(r['A']),B=''.join(r['B'])) for r in rooms.values()]
json.dump(out,open('site/rooms.json','w'),separators=(',',':'))
print(len(out),'rooms')
