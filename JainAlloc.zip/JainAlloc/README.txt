JainAlloc - hackathon classroom allocation
Open index.html by double-click. Keep index.html and data.js in the same folder.
data.js = map (graph.json) + room bookings (rooms.json) in one file.
parse.py / build.py rebuild rooms.json from the timetable PDF.
